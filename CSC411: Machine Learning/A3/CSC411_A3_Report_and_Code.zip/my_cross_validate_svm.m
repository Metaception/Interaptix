% Performs nfold cross-validation using tr_images/tr_labels on a parameter K
% If tr_identity is provided, uses that to do the split of the training images
% If tr_identity is not provided uses random permutations (disregards similar faces, bias in the training data)

function mean_acc = cross_validate(K, tr_images, tr_labels, nfold, tr_identity)

ntr = size(tr_images, 3);

if (~exist('tr_identity', 'var'))
  % random permutation (disregards similar faces)
  perm = randperm(ntr); 

  foldsize = floor(ntr/nfold);
  for i=1:nfold-1
    foldids{i} = (i-1)*foldsize+1:(i*foldsize);
  end
  foldids{nfold} = (nfold-1)*foldsize+1:ntr;
else
  % generally one uses random permutation to specify the splits, but because of the special structure of the dataset
  % we use the identity of poeple for this purpose.
  unknown = find(tr_identity == -1);
  tr_identity(unknown) = -(1:length(unknown));
  
  % finding people with the same identity
  [sid ind] = sort(tr_identity);
  [a b] = unique(sid);
  npeople = length(a);

  % separating out people with the same identity
  people = cell(npeople,1);
  people{1} = ind(1:b(1));
  for i=2:npeople
    people{i} = ind(b(i-1)+1:b(i))';
  end
  
  % shuffling people
  people = people(randperm(npeople));
  
  % dividing people into groups of roughly the same size but not necessarily
  foldsize = floor(npeople/nfold);
  for i=1:nfold-1
    foldids{i} = [people{(i-1)*foldsize+1:(i*foldsize)}];
  end
  foldids{nfold} = [people{(nfold-1)*foldsize+1:npeople}];
end



% perform nfold training and validation
runs = 12;          %the number of times mogEM is ran
min_vari = 0.01;    %The minimum variance allowed
num_images = ntr;   %the number of images
image_size = size(tr_images,1) * size(tr_images,2);
% TRAINING IMAGES
% test_image = zeros(image_size,num_images);
% for n = 1:num_images
%     image = tr_images(1:32,1:32,n);
%     test_image(1:image_size,n) = reshape(image,1,image_size);
% end


for i=1:nfold
  traini_ids = [foldids{[1:(i-1) (i+1):nfold]}];
  testi_ids = foldids{i};
  
  
%   %disp(size(tr_images(:, :, traini_ids)))
%   %disp(size(traini_ids))
%   %disp(size(tr_images(:, :, testi_ids)))
%   %disp(size(testi_ids))
%   %disp(tr_labels(traini_ids))
  
  num_images = size(traini_ids,2);
  vect_train_images = zeros(image_size,num_images); %vectors of images
  iter_train_images = tr_images(:, :, traini_ids);  %images for iteration
  iter_train_labels = tr_labels(traini_ids);        %labels for iteration
  iter_train_labels = reshape(iter_train_labels,1,num_images);
  
  %TRANSFERRING ALL TRAIN IMAGES IN THIS FOLD INTO VECTORS FOR mogEM
  for n = 1:num_images
      image = iter_train_images(:,:,n);
      vect_train_images(:,n) = reshape(image,1,image_size);
  end
  
  num_test = size(testi_ids,2);
  vect_test_images = zeros(image_size,num_test);
  iter_test_images = tr_images(:, :, testi_ids);
  iter_test_labels = tr_labels(testi_ids);
  iter_test_labels = reshape(iter_test_labels,1,num_test);
  
  for n = 1:num_test
      image = iter_test_images(:, :, n);
      vect_test_images(:,n) = reshape(image,1,image_size);
  end
  
  train_mu = mean(vect_train_images);
  test_mu = mean(vect_test_images);
  vect_train_images = bsxfun(@minus, vect_train_images, train_mu);
  vect_test_images = bsxfun(@minus, vect_test_images, test_mu);
  
  train_sd = var(vect_train_images);
  train_sd = train_sd + 0.01;
  train_sd = sqrt(train_sd);
  vect_train_images = bsxfun(@rdivide, vect_train_images, train_sd);
  
  test_sd = var(vect_test_images);
  test_sd = test_sd + 0.01;
  test_sd = sqrt(test_sd);
  vect_test_images = bsxfun(@rdivide, vect_test_images, test_sd);
  
%   % Subtract mean for each image
% tr_mu = mean(tr_images);
% test_mu = mean(test_images);
% tr_images = bsxfun(@minus, tr_images, tr_mu);
% test_images = bsxfun(@minus, test_images, test_mu);
% 
% % Normalize variance for each image
% tr_sd = var(tr_images);
% tr_sd = tr_sd + 0.01; % for extreme cases
% tr_sd = sqrt(tr_sd);
% tr_images = bsxfun(@rdivide, tr_images, tr_sd);  
  
  
  %t = templateKNN('NumNeighbors',3,'Standardize',1);
  %tTree = templateTree('MinLeafSize',20);
  %t = templateEnsemble('AdaBoostM1',100,tTree,'LearnRate',0.1);
  %t = templateSVM('KernelFunction','gaussian');
  %t = templateSVM('SaveSupportVectors',true);
  %mdl = fitcecoc(vect_train_images',iter_train_labels,'Learners',t);
  %mdl = fitcecoc(vect_train_images',iter_train_labels,'Coding','onevsall');
  %t = templateTree('AlgorithmForCategorical','Exact');
  %t = templateEnsemble('AdaBoostM2',100,'tree');
  t = templateSVM('KernelFunction','polynomial','PolynomialOrder',5);
  %t = templateSVM('Standardize','on');
  %t = templateSVM('KernelFunction','polynomial','IterationLimit',1e4,'PolynomialOrder',4,'OutlierFraction','ExpOut','Standardize',true);
  %t = templateSVM('KernelFunction','polynomial','PolynomialOrder',5,'Standardize',true);
  mdl = fitcecoc(vect_train_images',iter_train_labels,'Learners',t);
  %mdl = fitcecoc(vect_train_images',iter_train_labels);
%   disp(mdl)
%   disp(size(vect_train_images'))
%   disp(size(iter_train_labels))
  predi = predict(mdl,vect_test_images');
%   
%   train1 = [];
%   train2 = [];
%   train3 = [];
%   train4 = [];
%   train5 = [];
%   train6 = [];
%   train7 = [];
%   for n = 1:num_images
%       label = iter_train_labels(n);
%       image = vect_train_images(:,n);
%       if label == 1
%           index = size(train1,2) + 1;
%           train1(:,index) = image;
%       elseif label == 2
%           index = size(train2,2) + 1;
%           train2(:,index) = image;
%       elseif label == 3
%           index = size(train3,2) + 1;
%           train3(:,index) = image;
%       elseif label == 4
%           index = size(train4,2) + 1;
%           train4(:,index) = image;          
%       elseif label == 5
%           index = size(train5,2) + 1;
%           train5(:,index) = image;          
%       elseif label == 6
%           index = size(train6,2) + 1;
%           train6(:,index) = image;          
%       elseif label == 7
%           index = size(train7,2) + 1;
%           train7(:,index) = image;          
%       end
%   end
%   
%   [p1,mu1,vary1,logProbtr1] = mogEM(train1,K,runs,min_vari,0);
%   [p2,mu2,vary2,logProbtr2] = mogEM(train2,K,runs,min_vari,0);
%   [p3,mu3,vary3,logProbtr3] = mogEM(train3,K,runs,min_vari,0);
%   [p4,mu4,vary4,logProbtr4] = mogEM(train4,K,runs,min_vari,0);
%   [p5,mu5,vary5,logProbtr5] = mogEM(train5,K,runs,min_vari,0);
%   [p6,mu6,vary6,logProbtr6] = mogEM(train6,K,runs,min_vari,0);
%   [p7,mu7,vary7,logProbtr7] = mogEM(train7,K,runs,min_vari,0);
%   
%   logProb1 = mogLogProb(p1,mu1,vary1,vect_test_images);
%   logProb2 = mogLogProb(p2,mu2,vary2,vect_test_images);
%   logProb3 = mogLogProb(p3,mu3,vary3,vect_test_images);
%   logProb4 = mogLogProb(p4,mu4,vary4,vect_test_images);
%   logProb5 = mogLogProb(p5,mu5,vary5,vect_test_images);
%   logProb6 = mogLogProb(p6,mu6,vary6,vect_test_images);
%   logProb7 = mogLogProb(p7,mu7,vary7,vect_test_images);
%   
%   prob = [];
%   %disp(size(logProb1))
%   prob(1,:) = logProb1;
%   prob(2,:) = logProb2;
%   prob(3,:) = logProb3;
%   prob(4,:) = logProb4;
%   prob(5,:) = logProb5;
%   prob(6,:) = logProb6;
%   prob(7,:) = logProb7;
%   
%   [argval argmax] = max(prob);
%   predi = argmax';

  %predi = knn_classifier(K, tr_images(:, :, traini_ids), tr_labels(traini_ids), tr_images(:, :, testi_ids));
  prediknn = knn_classifier(K, tr_images(:, :, traini_ids), tr_labels(traini_ids), tr_images(:, :, testi_ids));
  
  
  % display([predi'; tr_labels(testi_ids)']);
  
  acc(i) = sum(predi == tr_labels(testi_ids))/length(foldids{i});
  disp(acc(i))
end

mean_acc = mean(acc);
