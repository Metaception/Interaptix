clear all
load labeled_images
load public_test_images
% load unlabeled_images
% 
% %**************************************************************************
% %***************************** INIT ***************************************
num_images = 2925;
image_size = 1024; %32x32
public_test_num = 1253;

% TRAINING IMAGES
test_image = zeros(image_size,num_images);
%test_id = zeros(1,num_images)

for n = 1:num_images
    image = tr_images(1:32,1:32,n);
    test_image(1:image_size,n) = reshape(image,1,image_size);
end
% %**************************************************************************
% The main function
% If test_images is provided, it will predict the results for those too, otherwise predicts 0 for the test cases.

load labeled_images.mat;
load public_test_images.mat;
load hidden_test_images.mat;

h = size(tr_images,1);
w = size(tr_images,2);

if ~exist('hidden_test_images', 'var')
  test_images = public_test_images;
else
  test_images = cat(3, public_test_images, hidden_test_images);
end


%Cross validation
% for K=[3:10 15 20 35 50]
%   nfold = 10;
%   acc(K) = my_cross_validate_svm(K, tr_images, tr_labels, nfold, tr_identity);
%   fprintf('%d-fold cross-validation with K=%d resulted in %.4f accuracy\n', nfold, K, acc(K));
% end


% Run the classifier
K = 30;
runs = 25;
min_vari = 0.01;

%prediction = knn_classifier(bestK, tr_images, tr_labels, test_images);
num_images = size(test_image,2);
vect_train_images = zeros(image_size,num_images); %vectors of images
iter_train_images = tr_images(:, :, :);  %images for iteration
iter_train_labels = tr_labels;        %labels for iteration
iter_train_labels = reshape(iter_train_labels,1,num_images);

%TRANSFERRING ALL TRAIN IMAGES IN THIS FOLD INTO VECTORS FOR mogEM
for n = 1:num_images
  image = tr_images(:,:,n);
  vect_train_images(:,n) = reshape(image,1,image_size);
end

% num_test = size(testi_ids,2);
vect_test_images = zeros(image_size,public_test_num);
% iter_test_images = tr_images(:, :, testi_ids);
% iter_test_labels = tr_labels(testi_ids);
% iter_test_labels = reshape(iter_test_labels,1,num_test);

for n = 1:public_test_num
  image = test_images(:, :, n);
  vect_test_images(:,n) = reshape(image,1,image_size);
end



% train_mu = mean(vect_train_images);
% test_mu = mean(vect_test_images);
% vect_train_images = bsxfun(@minus, vect_train_images, train_mu);
% vect_test_images = bsxfun(@minus, vect_test_images, test_mu);
% 
% train_sd = var(vect_train_images);
% train_sd = train_sd + 0.01;
% train_sd = sqrt(train_sd);
% vect_train_images = bsxfun(@rdivide, vect_train_images, train_sd);
% 
% test_sd = var(vect_test_images);
% test_sd = test_sd + 0.01;
% test_sd = sqrt(test_sd);
% vect_test_images = bsxfun(@rdivide, vect_test_images, test_sd);




% train1 = [];
% train2 = [];
% train3 = [];
% train4 = [];
% train5 = [];
% train6 = [];
% train7 = [];
% for n = 1:num_images
%   label = iter_train_labels(n);
%   image = vect_train_images(:,n);
%   if label == 1
%       index = size(train1,2) + 1;
%       train1(:,index) = image;
%   elseif label == 2
%       index = size(train2,2) + 1;
%       train2(:,index) = image;
%   elseif label == 3
%       index = size(train3,2) + 1;
%       train3(:,index) = image;
%   elseif label == 4
%       index = size(train4,2) + 1;
%       train4(:,index) = image;          
%   elseif label == 5
%       index = size(train5,2) + 1;
%       train5(:,index) = image;          
%   elseif label == 6
%       index = size(train6,2) + 1;
%       train6(:,index) = image;          
%   elseif label == 7
%       index = size(train7,2) + 1;
%       train7(:,index) = image;          
%   end
% end
% 
% [p1,mu1,vary1,logProbtr1] = mogEM(train1,K,runs,min_vari,0);
% [p2,mu2,vary2,logProbtr2] = mogEM(train2,K,runs,min_vari,0);
% [p3,mu3,vary3,logProbtr3] = mogEM(train3,K,runs,min_vari,0);
% [p4,mu4,vary4,logProbtr4] = mogEM(train4,K,runs,min_vari,0);
% [p5,mu5,vary5,logProbtr5] = mogEM(train5,K,runs,min_vari,0);
% [p6,mu6,vary6,logProbtr6] = mogEM(train6,K,runs,min_vari,0);
% [p7,mu7,vary7,logProbtr7] = mogEM(train7,K,runs,min_vari,0);
% 
% logProb1 = mogLogProb(p1,mu1,vary1,vect_test_images);
% logProb2 = mogLogProb(p2,mu2,vary2,vect_test_images);
% logProb3 = mogLogProb(p3,mu3,vary3,vect_test_images);
% logProb4 = mogLogProb(p4,mu4,vary4,vect_test_images);
% logProb5 = mogLogProb(p5,mu5,vary5,vect_test_images);
% logProb6 = mogLogProb(p6,mu6,vary6,vect_test_images);
% logProb7 = mogLogProb(p7,mu7,vary7,vect_test_images);
% 
% prob = [];
% %disp(size(logProb1))
% prob(1,:) = logProb1;
% prob(2,:) = logProb2;
% prob(3,:) = logProb3;
% prob(4,:) = logProb4;
% prob(5,:) = logProb5;
% prob(6,:) = logProb6;
% prob(7,:) = logProb7;

%t = templateSVM('SaveSupportVectors',true);
t = templateSVM('Standardize','on');
mdl = fitcecoc(vect_train_images',iter_train_labels,'Learners',t);
%mdl = fitcecoc(vect_train_images',iter_train_labels);
%   disp(mdl)
%   disp(size(vect_train_images'))
%   disp(size(iter_train_labels))
prediction = predict(mdl,vect_test_images');

% [argval argmax] = max(prob);
% prediction = argmax';

% Fill in the test labels with 0 if necessary
if (length(prediction) < 1253)
  prediction = [prediction; zeros(1253-length(prediction), 1)];
end

% Print the predictions to file
fprintf('writing the output to prediction.csv\n');
fid = fopen('prediction.csv', 'w');
fprintf(fid,'Id,Prediction\n');
for i=1:length(prediction)
  fprintf(fid, '%d,%d\n', i, prediction(i));
end
fclose(fid);

clear tr_images hidden_test_images public_test_images

% %**************************************************************************
% %******************* FROM INIT_NN IN ASSIGNMENT 2 *************************
% % initialize the net structure.
% num_inputs = size(inputs_train, 1);
% num_hiddens = 30;%NUMBER OF HIDDEN UNITS IS 10 ORIGINAL, TRY 2,5,30,100
% num_outputs = 1;
% 
% %%% make random initial weights smaller, and include bias weights
% W1 = 0.01 * randn(num_inputs, num_hiddens);
% b1 = zeros(num_hiddens, 1);
% W2 = 0.01 * randn(num_hiddens, num_outputs);
% b2 = zeros(num_outputs, 1);
% 
% dW1 = zeros(size(W1));
% dW2 = zeros(size(W2));
% db1 = zeros(size(b1));
% db2 = zeros(size(b2));
% 
% eps = 0.5;  %% the learning rate  %ORIGINAL IS .1 TRY .01,.2,.5 FOR 2.3
% momentum = 0.5;   %% the momentum coefficient %ORIGINAL 0 TRY .5,.9 FOR 2.3
% 
% num_epochs = 100; %% number of learning epochs (number of passes through the
%                  %% training set) each time runbp is called.
% 
% total_epochs = 0; %% number of learning epochs so far. This is incremented 
%                     %% by numEpochs each time runbp is called.
% 
% %%% For plotting learning curves:
% min_epochs_per_plot = 200;
% train_errors = zeros(1, min_epochs_per_plot);
% valid_errors = zeros(1, min_epochs_per_plot);
% epochs = [1 : min_epochs_per_plot];

