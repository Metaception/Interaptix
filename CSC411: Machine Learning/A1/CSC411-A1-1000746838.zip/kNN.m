clc
close
clear
load mnist_train.mat;
load mnist_valid.mat;
load mnist_test.mat;

hold on
%Validation Performance
classif = zeros(1, 5);
for k = 1:2:9
    valid_labels        = run_knn( k, train_inputs, train_targets, valid_inputs );
    classif( (k+1)/2 )  = sum( ~xor( valid_labels, valid_targets ) )/size(valid_labels, 1);
end
plot( [1, 3, 5, 7, 9], classif*100 )

%Test Performance
classif = zeros(1, 5);
for k = 1:2:9
    test_labels        = run_knn( k, train_inputs, train_targets, test_inputs );
    classif( (k+1)/2 )  = sum( ~xor( test_labels, test_targets ) )/size(test_labels, 1);
end
plot( [1, 3, 5, 7, 9], classif*100 )
title('kNN')
ylabel('Classification Rate')
xlabel('Values of k')
legend('Validation', 'Test')
hold off