%% Clear workspace.
clear all;
close all;
clc

%% Load data.
load mnist_train;
load mnist_train_small;
load mnist_valid;
load mnist_test;

% Uncomment if using test data
%valid_inputs    = test_inputs;
%valid_targets   = test_targets;

% Uncomment if using train_small
%train_inputs     = train_inputs_small;
%train_targets    = train_targets_small;

%% TODO: Initialize hyperparameters.
% Learning rate
hyperparameters.learning_rate           = 0.85;
% Weight regularization parameter
hyperparameters.weight_regularization   = 1;
% Number of iterations
hyperparameters.num_iterations          = 142;
% Lambda Values
pos_lambda                              = [0.001, 0.01, 0.1, 1];

% Initialize plot storage
cross_train  = zeros(1, 4);
cross_valid  = zeros(1, 4);
class_train  = zeros(1, 4);
class_valid  = zeros(1, 4);

%%Loop through the lambda
for lam = 1:4
    hyperparameters.lambda = pos_lambda(lam);
    %% Verify that your logistic function produces the right gradient, diff should be very close to 0
    % this creates small random data with 20 examples and 10 dimensions and checks the gradient on
    % that data.
    nexamples = 20;
    ndimensions = 10;
    diff = checkgrad('logistic_pen', ...
                     randn((ndimensions + 1), 1), ...   % weights
                     0.001,...                          % perturbation
                     randn(nexamples, ndimensions), ... % data        
                     rand(nexamples, 1), ...            % targets
                     hyperparameters)                   % other hyperparameters

    N = size( train_targets, 1 );

    %% Loop 10 times
    for n = 1:10
        % Logistics regression weights
        % TODO: Set random weights.
        weights     = 0.42*randn( 784+1, 1 );
        
        %% Begin learning with gradient descent.
        for t = 1:hyperparameters.num_iterations
            %% TODO: You will need to modify this loop to create plots etc.

            % Find the negative log likelihood and derivative w.r.t. weights.
            [f, df, predictions] = logistic_pen(weights, ...
                                                   train_inputs, ...
                                                   train_targets, ...
                                                   hyperparameters);

            [cross_entropy_train, frac_correct_train] = evaluate(train_targets, predictions);

            % Find the fraction of correctly classified validation examples.
            [temp, temp2, frac_correct_valid] = logistic_pen(weights, ...
                                                         valid_inputs, ...
                                                         valid_targets, ...
                                                         hyperparameters);

            if isnan(f) || isinf(f)
                error('nan/inf error');
            end

            %% Update parameters.
            weights = weights - hyperparameters.learning_rate .* df / N;

            predictions_valid = logistic_predict(weights, valid_inputs);
            [cross_entropy_valid, frac_correct_valid] = evaluate(valid_targets, predictions_valid);

            %% Print some stats.
            %fprintf(1, 'ITERATION:%4i   NLOGL:%4.2f TRAIN CE %.6f TRAIN FRAC:%2.2f VALIC_CE %.6f VALID FRAC:%2.2f\n',...
                    %t, f/N, cross_entropy_train, frac_correct_train*100, cross_entropy_valid, frac_correct_valid*100);
        end
        
        % Update cross entropy and classification error
        cross_train(lam)  = cross_train(lam) + cross_entropy_train/10;
        cross_valid(lam)  = cross_train(lam) + cross_entropy_valid/10;
        class_train(lam)  = class_train(lam) + (1 - frac_correct_train)/10;
        class_valid(lam)  = class_train(lam) + (1 - frac_correct_valid)/10;
    end
end
%% Plot
hold on
plot( pos_lambda, cross_train )
plot( pos_lambda, cross_valid )
title('Cross Entropy - Penalized')
xlabel('Lambda')
ylabel('Bits')
legend('Training', 'Validation')
hold off

figure;
hold on
plot( pos_lambda, class_train )
plot( pos_lambda, class_valid )
title('Classification Error - Penalized')
xlabel('Lambda')
ylabel('%')
legend('Training', 'Validation')
hold off
