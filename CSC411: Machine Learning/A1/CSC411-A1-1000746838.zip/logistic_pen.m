function [f, df, y] = logistic_pen(weights, data, targets, hyperparameters)
% Calculate log likelihood and derivatives with respect to weights.
%
% Note: N is the number of examples and 
%       M is the number of features per example.
%
% Inputs:
% 	weights:    (M+1) x 1 vector of weights, where the last element
%               corresponds to bias (intercepts).
% 	data:       N x M data matrix where each row corresponds 
%               to one data point.
%	targets:    N x 1 vector of targets class probabilities.
%   hyperparameters: The hyperparameter structure
%
% Outputs:
%	f:             The scalar error value.
%	df:            (M+1) x 1 vector of derivatives of error w.r.t. weights.
%   y:             N x 1 vector of probabilities. This is the output of the classifier.
%

%TODO: finish this function
    M       = size(weights, 1) - 1;
    N       = size(targets, 1);
    
    w       = hyperparameters.weight_regularization * weights( 1:M );
    bias    = weights( M + 1 );
    z       = data*w + bias;
    
    y   = logistic_predict( hyperparameters.weight_regularization * weights, data );
    f   = targets'*z;
    for i = 1:N
        f = f + log( 1 + exp( -z(i) ) );
    end
    for j = 1:M
        f = f + hyperparameters.lambda/2 * w(j)^2;
    end
    
    df = zeros( M + 1, 1 );
    % Find the deviatives w.r.t. the weights
    for j = 1:M
        df(j)   = data(:,j)' * ( targets - sigmoid(-z) ) + hyperparameters.lambda * w(j);
    end
    df( M + 1 ) = ones(1, N) * ( targets - sigmoid(-z) );   %Derivative for w.r.t. bias
end